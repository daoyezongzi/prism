Prism 产品演示

启动：安装有 Python 3.9 或以上版本的 Windows 电脑双击 start-demo.cmd，将自动打开浏览器；其他系统运行 python preview.py --open。
重复启动会复用已有演示服务。首次启动的窗口需保持打开；关闭该窗口将停止服务。
如 8860 被其他服务占用，窗口会说明原因；可运行 start-demo.cmd --port 8861 改用其他端口。
打开：http://127.0.0.1:8860/demos/product-demo/#overview
截图：http://127.0.0.1:8860/demos/product-demo/?capture=1#overview

9 页导航可直接切换。截图模式隐藏演示工具栏，“演示数据”标记一直保留。
Esc 先关闭引用，未打开引用时退出截图模式。重置演示恢复固定初始状态。
所有资料、数值、工具选择和任务状态均为演示样例；不连接真实金融数据、模型或账户。
不含用户数据、凭据或模型权重；Lightweight Charts 授权见 static/lightweight-charts.LICENSE.txt。
