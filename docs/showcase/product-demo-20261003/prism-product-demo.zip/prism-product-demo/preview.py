from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
root = Path(__file__).resolve().parent / "static"
print("Open http://127.0.0.1:8860/demos/product-demo/#overview", flush=True)
with ThreadingHTTPServer(("127.0.0.1", 8860), partial(SimpleHTTPRequestHandler, directory=str(root))) as server:
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
