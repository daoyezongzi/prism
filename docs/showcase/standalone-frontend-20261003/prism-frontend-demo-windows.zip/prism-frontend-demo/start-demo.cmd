@echo off
setlocal
cd /d "%~dp0"
if exist "preview.exe" (
  "preview.exe" --open %*
  goto :done
)
py -3 -c "import sys; raise SystemExit(sys.version_info < (3, 9))" >nul 2>nul
if not errorlevel 1 (
  py -3 "preview.py" --open %*
  goto :done
)
py -c "import sys; raise SystemExit(sys.version_info < (3, 9))" >nul 2>nul
if not errorlevel 1 (
  py "preview.py" --open %*
  goto :done
)
python -c "import sys; raise SystemExit(sys.version_info < (3, 9))" >nul 2>nul
if not errorlevel 1 (
  python "preview.py" --open %*
  goto :done
)
for /f "delims=" %%P in ('where python 2^>nul') do (
  "%%P" -c "import sys; raise SystemExit(sys.version_info < (3, 9))" >nul 2>nul
  if not errorlevel 1 (
    "%%P" "preview.py" --open %*
    goto :done
  )
)
echo Python 3.9 or newer is required. Install Python with its Windows launcher or add Python to PATH.
pause
exit /b 1
:done
set "demo_exit_code=%errorlevel%"
if errorlevel 1 pause
endlocal & exit /b %demo_exit_code%
